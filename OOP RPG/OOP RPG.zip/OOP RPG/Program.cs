﻿using static System.Console;

namespace OOP_RPG
{
    internal static class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.Start();

        }
    }
}
